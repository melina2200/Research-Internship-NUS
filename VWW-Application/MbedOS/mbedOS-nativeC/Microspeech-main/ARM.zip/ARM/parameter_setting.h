#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  //Header file for sleep(). man 3 sleep for details.
// #include <pthread.h>
#include <stdint.h>

#define C1 80
#define R1 8
#define C2 504
#define R2 C1

#define P 12//P

#define R3 4000
#define C3 4

extern const int8_t WEIGHT_MATRIX[R1*C1];
extern const int8_t DENSE_MATRIX[R3*C3];
// extern const int8_t TEST_DATA[49*40];
extern const int8_t INPUT_MATRIX[R2*C2];

